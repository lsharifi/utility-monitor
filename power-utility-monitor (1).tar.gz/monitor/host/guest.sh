# ex: 192.168.56.1 5000 stop kvm-demo sigar
# $1 cmd = start | stop
# $2 monitor_name
# $3 type = cpufreq | sigar | perf 
java -classpath monitor.jar:. HostSignalizer bscgrid29 5000 $1 $2 $3
