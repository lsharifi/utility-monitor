# args[0] local waiting port
java -classpath monitor.jar:sigar.jar:. MonitorWaiter bscgrid29 5000 bscgrid29 5005 /dev/sda
