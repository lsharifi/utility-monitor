# start monitors
#
echo "Start Monitoring"
#./guest.sh start $bench-watts watts
./guest.sh start freq cpufreq
./guest.sh start sigar sigar
./guest.sh start perf perf
date +%s>starttimestamp.csv
#
