dir_name="guest"
echo $dir_name
# start monitors
#
echo "Start Monitoring"
#./guest.sh start $bench-watts watts
./guest.sh start $bench-freq cpufreq
./guest.sh start $bench-sigar sigar
./guest.sh start $bench-perf perf
cd ../hadoop-2.6.0
echo $(pwd)
date +%s>../$dir_name/starttimestamp.csv
#
# start terasort
#
bin/hadoop jar share/hadoop/mapreduce/hadoop-mapreduce-examples-2.6.0.jar wordcount -D mapred.map.tasks=2 -D mapred.reduce.tasks=2 teraInput wordcountOutput 2>/dev/null 1>/dev/null
#
# stop monitors
#
date +%s>../$dir_name/stoptimestamp.csv
cd ../run-on-29
echo $(pwd)
#./guest.sh stop $bench-watts watts
./guest.sh stop $bench-freq cpufreq
./guest.sh stop $bench-sigar sigar
./guest.sh stop $bench-perf perf
python bsc-ganglia-power.py -d "wordcount/" -tsstart $(cat starttimestamp.csv) -tsend $(cat stoptimestamp.csv)

rm starttimestamp.csv
rm stoptimestamp.csv
