#!/bin/bash 

benchmarks=(470.lbm 453.povray 462.libquantum 464.h264ref)
#benchmarks=(464.h264ref)

for bench in "${benchmarks[@]}"
do
	#
	# start monitors
	#
#	./guest.sh start $bench-watts watts
	./guest.sh start $bench-freq cpufreq
	./guest.sh start $bench-sigar sigar
	./guest.sh start $bench-perf perf
	date +%s>starttimestamp.csv	
	#
	# start CPUSPEC2006 benchmark
	#
	runspec --config=leila-gcc43+.cfg --size=ref --noreportable --tune=base --iterations=1 $bench

	#
	# stop monitors
	#
	date +%s>stoptimestamp.csv
#	./guest.sh stop $bench-watts watts
	./guest.sh stop $bench-freq cpufreq
	./guest.sh stop $bench-sigar sigar
	./guest.sh stop $bench-perf perf
	python bsc-ganglia-power.py -d "spec/"$bench"/" -tsstart $(cat starttimestamp.csv) -tsend $(cat stoptimestamp.csv)
done
rm starttimestamp.csv
rm stoptimestamp.csv
