__author__ = 'navaneeth'
import os
import json
import urllib2
import ast
import csv
import argparse
import os
import shutil

dirname = "ganglia/"
timestamp_start = None
timestamp_end = None

instance_id = "instance-000026c2"

basic_host_metrics = ["cpu_user","cpu_system","cpu_wio","mem_cached","bytes_read","bytes_written",
                    "powerWatts","bytes_in","bytes_out","drops_in","drops_out",
                   "errs_in","errs_out","pkts_in","pkts_out"]

basic_vm_metrics =["vcpu_util","vdisk_bytes_read","vdisk_bytes_written","vdisk_reads","vdisk_writes",
"vmem_util","vbytes_in","vbytes_out","vdrops_in","vdrops_out","verrs_in","verrs_out","vpkts_in","vpkts_out"]

hosts = ["bscgrid29"]

def create_dir(dirname):
    os.umask(0000)
    if os.path.exists(dirname):
        shutil.rmtree(dirname)
        os.makedirs(dirname)
    else:
        os.makedirs(dirname)

def get_host_data():
    for host in hosts:
        for metric in basic_host_metrics:
            url = get_url(host,metric)
            response = urllib2.urlopen(url)
            output = response.read()
            data = json.loads(output)
            values = write_values_from_json(host, metric, data[0])

def get_vm_data():
    for host in hosts:
        for metric in basic_vm_metrics:
            instance_metric = instance_id+"."+metric 
            url = get_url(host,instance_metric)
            response = urllib2.urlopen(url)
            output = response.read()
            data = json.loads(output)
            values = write_values_from_json(host, instance_metric, data[0])


def write_values_from_json(host, metric,data):
    temp_list =[]
    file_handle = open(dirname+host+'-'+metric,'w')
    temp_list.append(metric)

    for value in data['datapoints']:
        temp_list.append(value[0])

    file_handle.write(json.dumps(temp_list))
    file_handle.close()

def get_url(host,metric):
    return (" http://bscgrid28.bsc.es/ganglia2/api/query_json.php?&cluster=testing-cloud&host="
    +host+"&metric=" +metric+"&start="+timestamp_start+"&end="+timestamp_end)


def write_csv(name):
    ofile_handle = open(name,'w')
    writer = csv.writer(ofile_handle)

    all_data = []
    for filename in os.listdir(dirname):
        if filename[:7]== "bscgrid":
            print filename
            ifile_handle = open(dirname+filename,'r')
            all_data.append(ast.literal_eval(ifile_handle.readline()))
            ifile_handle.close()

    print all_data
    rows= zip(*all_data)

    for row in rows:
        writer.writerow(row)

if __name__ =='__main__':
	
    parser = argparse.ArgumentParser()
    parser.add_argument('-d','--dir', action = "store", dest = 'dir', help = "Use this argument to generate folder name for storing the files. Example: memcached-mbw/" )
    parser.add_argument('-tsstart','--timestampstart', action = "store", dest = 'timestampstart', help = "Use this argument to enter beginning timestamp. Example: 1444216032" )
    parser.add_argument('-tsend','--timestampend', action = "store", dest = 'timestampend', help = "Use this argument to enter beginning timestamp. Example: 1444216032" )
    args = vars(parser.parse_args())
    print args
    if not args['timestampstart'] or not args['timestampend']:
        parser.error("Both -tsstart and -tsend must be given")
	
    if args['dir']:
        dirname = args['dir']
    if args['timestampstart']:
        timestamp_start = args['timestampstart']
    if args['timestampend']:
        timestamp_end = args ['timestampend']
	
	create_dir(dirname)

    get_host_data()
    get_vm_data()
    write_csv(dirname+"all_data.csv")

