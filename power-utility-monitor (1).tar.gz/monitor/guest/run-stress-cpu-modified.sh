#!/bin/bash 

timeout=30
cores=1

while [  $cores -le 32 ]; do
	for perc_utz in 20 40 60 80 95
	do
        mname="cpu-"$cores"-util-"$perc_utz

	echo "++++" running monitor $mname "++++"
	
	#
	# start monitors
	#
        #./guest.sh start $mname-watts watts
	./guest.sh start $mname-freq cpufreq
	./guest.sh start $mname-sigar sigar
	./guest.sh start $mname-perf perf
	date +%s>starttimestamp.csv
	#
	# start stress 30 seconds
	#
	stress -c $cores &
	#
	# cpu limit
	#
	ARRAY1=' ' read -a IDs <<< $(pidof stress)
	for element in ${IDs[@]}
	do
		cpulimit -p $element -l $perc_utz &
	done
	#
	# wait timeout
	#
	sleep $timeout
	#
	# stop monitors
	#
	date +%s>stoptimestamp.csv
        #./guest.sh stop $mname-watts watts
	./guest.sh stop $mname-freq cpufreq
	./guest.sh stop $mname-sigar sigar
	./guest.sh stop $mname-perf perf
	killall stress
	python bsc-ganglia-power.py -d $mname"/" -tsstart $(cat starttimestamp.csv) -tsend $(cat stoptimestamp.csv)
	done
	cores=$((cores+1))
done
