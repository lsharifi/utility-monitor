# args[0] local waiting port
java -classpath monitor.jar:sigar.jar:. MonitorWaiter 5000 bscgrid29 5005 /dev/sda
