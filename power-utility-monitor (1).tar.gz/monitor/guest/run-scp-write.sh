# start monitors
#
echo "Start Monitoring"
#./guest.sh start $bench-watts watts
./guest.sh start $bench-freq cpufreq
./guest.sh start $bench-sigar sigar
./guest.sh start $bench-perf perf
date +%s>starttimestamp.csv
#
# start copy cloudy to bscgrid28

scp -r  lsharifi@bscgrid28.bsc.es:~/cloudy ./cloudy
#
# stop monitors
#
date +%s>stoptimestamp.csv
#./guest.sh stop $bench-watts watts
./guest.sh stop $bench-freq cpufreq
./guest.sh stop $bench-sigar sigar
./guest.sh stop $bench-perf perf
python bsc-ganglia-power.py -d "scp_write/" -tsstart $(cat starttimestamp.csv) -tsend $(cat stoptimestamp.csv)

rm starttimestamp.csv
rm stoptimestamp.csv
