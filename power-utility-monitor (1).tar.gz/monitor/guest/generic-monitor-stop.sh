
# stop monitors
#
date +%s>stoptimestamp.csv
#./guest.sh stop $bench-watts watts
./guest.sh stop freq cpufreq
./guest.sh stop sigar sigar
./guest.sh stop perf perf
python bsc-ganglia-power.py -d "generic/" -tsstart $(cat starttimestamp.csv) -tsend $(cat stoptimestamp.csv)

rm starttimestamp.csv
rm stoptimestamp.csv
