num_cores=$(cat /proc/cpuinfo | grep processor | wc -l)
echo "number of cores="$num_cores

# args[0] local waiting port
java -classpath monitor.jar:. SocketInfoReceiver 5005 $num_cores
